# Init file for the hyprland-whisper-stt package
# This makes the src directory a proper Python package