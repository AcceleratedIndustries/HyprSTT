#!/bin/bash
# Niri-optimized run script for Hyprland Whisper STT

# Change to the script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

# Create log directory
mkdir -p ~/.local/share/whisper-stt/logs

# Check if already running
if pgrep -f "python -m src.main" > /dev/null; then
    notify-send "Whisper STT" "Already running! Use F9 to toggle recording."
    exit 0
fi

# Check if virtual environment exists
if [ -d "venv" ]; then
    source venv/bin/activate
elif [ -d ".venv" ]; then
    source .venv/bin/activate
fi

# Make sure we're in the right directory
export PYTHONPATH=$SCRIPT_DIR:$PYTHONPATH

# Set environment variables for Niri compatibility
export WAYLAND_DISPLAY=${WAYLAND_DISPLAY:-wayland-1}
export XDG_SESSION_TYPE=wayland

# Run the application in background
nohup python -m src.main > ~/.local/share/whisper-stt/logs/whisper-stt.log 2>&1 &
APP_PID=$!

# Wait a moment for the app to start
sleep 2

# Check if the application started successfully
if kill -0 $APP_PID 2>/dev/null; then
    notify-send "Whisper STT" "Service started successfully! Use F9 to toggle recording." -t 5000
    echo "Whisper STT started with PID: $APP_PID"
    echo $APP_PID > ~/.local/share/whisper-stt/whisper-stt.pid
else
    notify-send "Whisper STT" "Failed to start service. Check logs for details." -t 5000
    echo "Failed to start Whisper STT"
    exit 1
fi