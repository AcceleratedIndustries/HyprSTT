#!/bin/bash
# Stop script for Whisper STT

# Kill the process if running
if pgrep -f "python -m src.main" > /dev/null; then
    pkill -f "python -m src.main"
    
    # Remove PID file if it exists
    if [ -f ~/.local/share/whisper-stt/whisper-stt.pid ]; then
        rm ~/.local/share/whisper-stt/whisper-stt.pid
    fi
    
    notify-send "Whisper STT" "Service stopped."
    echo "Whisper STT stopped."
else
    echo "Whisper STT is not running."
fi